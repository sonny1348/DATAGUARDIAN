
import random

class FileSystem:
    def __init__(self, os_type):
        self.os_type = os_type
        self.recovery_chances = {
            "Windows": {
                "Recycle Bin": 0.95,
                "NTFS Journal": 0.85,
                "Shadow Copy": 0.75
            },
            "MacOS": {
                "Trash": 0.95,
                "Time Machine": 0.90,
                "File System Snapshot": 0.80
            }
        }

    def calculate_recovery_probability(self, deletion_type):
        """Calculate the probability of successful recovery based on OS and deletion type"""
        base_probability = self.recovery_chances[self.os_type].get(deletion_type, 0.5)
        # Factors that affect real recovery:
        time_factor = random.uniform(-0.2, 0)  # Recovery success decreases with time
        disk_activity = random.uniform(-0.15, 0)  # Disk activity can overwrite data
        random_factor = time_factor + disk_activity
        return min(1.0, max(0.0, base_probability + random_factor))

    def get_recovery_steps(self):
        """Return recovery steps based on OS type"""
        if self.os_type == "Windows":
            return [
                "Check Recycle Bin",
                "Scan NTFS Journal", 
                "Check Shadow Copies",
                "Deep Scan File System"
            ]
        else:  # MacOS
            return [
                "Check Trash",
                "Search Time Machine Backups",
                "Check File System Snapshots",
                "Scan Directory Structure"
            ]
