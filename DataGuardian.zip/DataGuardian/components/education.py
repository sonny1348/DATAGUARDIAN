import streamlit as st
import plotly.graph_objects as go

def show_educational_content():
    st.header("Educational Guide")

    tab1, tab2, tab3 = st.tabs(["Basic Concepts", "Recovery Methods", "Technical Terms"])

    with tab1:
        st.subheader("What happens when a file is deleted?")
        st.write("""
        1. **Windows (Recycle Bin)**
        - Files aren't immediately deleted
        - Moved to Recycle Bin
        - File record marked as deleted
        - Space marked as available

        2. **MacOS (Trash)**
        - Files moved to Trash
        - Metadata preserved
        - Time Machine keeps backups
        - Space marked as reusable
        """)

        # Create comparison chart
        labels = ['Immediate Recovery', 'Long-term Recovery', 'Automatic Backup', 'File Versioning']
        windows_values = [9, 7, 6, 5]
        macos_values = [8, 8, 9, 8]

        fig = go.Figure(data=[
            go.Bar(name='Windows', x=labels, y=windows_values, marker_color='lightblue'),
            go.Bar(name='MacOS', x=labels, y=macos_values, marker_color='lightgreen')
        ])

        fig.update_layout(
            title="Recovery Feature Comparison",
            yaxis_title="Effectiveness (1-10)",
            barmode='group'
        )

        st.plotly_chart(fig)

    with tab2:
        st.subheader("Recovery Methods Explained")

        col1, col2 = st.columns(2)

        with col1:
            st.markdown("### Windows Recovery Commands")
            st.code("""
# Remove file attributes
attrib -h -r -s /s /d C:

# Check and repair disk
chkdsk /f /r

# Check system files
sfc /scannow
            """)

            st.write("""
            **What these commands do:**
            1. `attrib`: Removes hidden, read-only, and system attributes
            2. `chkdsk`: Checks disk for errors and repairs them
            3. `sfc`: Scans and repairs Windows system files
            """)

        with col2:
            st.markdown("### MacOS Recovery Commands")
            st.code("""
# List Time Machine backups
tmutil listlocal

# Restore from Time Machine
tmutil restore

# Show file metadata
mdls [filename]
            """)

            st.write("""
            **What these commands do:**
            1. `tmutil listlocal`: Shows available backups
            2. `tmutil restore`: Recovers files from backup
            3. `mdls`: Displays file information and metadata
            """)

    with tab3:
        st.subheader("Technical Terms Simplified")

        terms = {
            "MFT (Master File Table)": "Like a book's index for all files on Windows",
            "File Record": "Information card about each file",
            "Journal": "A diary of all changes made to files",
            "Time Machine": "MacOS's automatic backup system",
            "File System": "The way computers organize and store files",
            "Metadata": "Information about a file (size, date, etc.)"
        }

        for term, definition in terms.items():
            with st.expander(term):
                st.write(definition)