import streamlit as st
import plotly.graph_objects as go
import networkx as nx

def create_file_system_tree(os_type):
    G = nx.Graph()
    
    if os_type == "Windows":
        nodes = [
            ("C:", 0), ("System", 1), ("Users", 1), ("Recovery", 1),
            ("Documents", 2), ("Downloads", 2), ("RecycleBin", 2)
        ]
    else:  # MacOS
        nodes = [
            ("/", 0), ("Applications", 1), ("Users", 1), ("System", 1),
            ("Documents", 2), ("Downloads", 2), ("Trash", 2)
        ]
    
    # Add nodes and edges
    for node, level in nodes:
        G.add_node(node, level=level)
        if level > 0:
            parent = [n for n, l in nodes if l == level-1][0]
            G.add_edge(parent, node)
    
    return G

def show_file_system_comparison():
    st.header("File System Visualization")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Windows File System")
        G_windows = create_file_system_tree("Windows")
        pos_windows = nx.spring_layout(G_windows)
        
        edge_trace = go.Scatter(
            x=[], y=[], line=dict(width=1, color='#888'),
            hoverinfo='none', mode='lines')
        
        for edge in G_windows.edges():
            x0, y0 = pos_windows[edge[0]]
            x1, y1 = pos_windows[edge[1]]
            edge_trace['x'] += (x0, x1, None)
            edge_trace['y'] += (y0, y1, None)
            
        node_trace = go.Scatter(
            x=[], y=[], text=[], mode='markers+text',
            hoverinfo='text', marker=dict(size=20, color='lightblue'))
            
        for node in G_windows.nodes():
            x, y = pos_windows[node]
            node_trace['x'] += (x,)
            node_trace['y'] += (y,)
            node_trace['text'] += (node,)
            
        fig_windows = go.Figure(data=[edge_trace, node_trace],
                              layout=go.Layout(showlegend=False))
        st.plotly_chart(fig_windows)

    with col2:
        st.subheader("MacOS File System")
        G_macos = create_file_system_tree("MacOS")
        pos_macos = nx.spring_layout(G_macos)
        
        edge_trace = go.Scatter(
            x=[], y=[], line=dict(width=1, color='#888'),
            hoverinfo='none', mode='lines')
        
        for edge in G_macos.edges():
            x0, y0 = pos_macos[edge[0]]
            x1, y1 = pos_macos[edge[1]]
            edge_trace['x'] += (x0, x1, None)
            edge_trace['y'] += (y0, y1, None)
            
        node_trace = go.Scatter(
            x=[], y=[], text=[], mode='markers+text',
            hoverinfo='text', marker=dict(size=20, color='lightgreen'))
            
        for node in G_macos.nodes():
            x, y = pos_macos[node]
            node_trace['x'] += (x,)
            node_trace['y'] += (y,)
            node_trace['text'] += (node,)
            
        fig_macos = go.Figure(data=[edge_trace, node_trace],
                            layout=go.Layout(showlegend=False))
        st.plotly_chart(fig_macos)
