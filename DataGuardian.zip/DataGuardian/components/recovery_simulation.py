import streamlit as st
import plotly.graph_objects as go
import time
import random
import numpy as np
from data.recovery_info import RecoveryInfo

def create_helix_frame(step, total_points, recovered_points, os_type, step_name):
    """Create an animation frame showing DNA-like double helix recovery visualization"""
    t = np.linspace(0, 8*np.pi, total_points)

    # Calculate base coordinates for double helix
    x1 = np.cos(t)
    y1 = np.sin(t)
    z1 = t

    x2 = np.cos(t + np.pi)
    y2 = np.sin(t + np.pi)
    z2 = t

    # Color scheme for different recovery stages
    color_scheme = {
        "Checking": "#FFE1A1",  # Light yellow
        "Scanning": "#C1E1C1",  # Light green
        "Analyzing": "#B7E4F9",  # Light blue
        "Recovering": "#90EE90",  # Green
    }

    # Get stage color based on step name
    stage_color = next((color for stage, color in color_scheme.items() 
                       if stage in step_name), "#90EE90")

    # Create connecting lines between helices
    x_connect = []
    y_connect = []
    z_connect = []
    connect_colors = []

    for i in range(total_points):
        if i % 4 == 0:  # Add connecting lines every 4 points
            x_connect.extend([x1[i], x2[i], None])
            y_connect.extend([y1[i], y2[i], None])
            z_connect.extend([z1[i], z2[i], None])
            connect_colors.extend([stage_color if i < recovered_points else 'lightgray'])

    # Create frame with traces
    frame = go.Frame(
        data=[
            # First helix strand
            go.Scatter3d(
                x=x1[:recovered_points], y=y1[:recovered_points], z=z1[:recovered_points],
                mode='lines+markers',
                line=dict(color=stage_color, width=4),
                marker=dict(size=4, color=stage_color),
                name='Recovered Data'
            ),
            # Remaining unrecovered part of first strand
            go.Scatter3d(
                x=x1[recovered_points:], y=y1[recovered_points:], z=z1[recovered_points:],
                mode='lines+markers',
                line=dict(color='lightgray', width=2),
                marker=dict(size=3, color='lightgray'),
                name='Pending Recovery'
            ),
            # Second helix strand
            go.Scatter3d(
                x=x2[:recovered_points], y=y2[:recovered_points], z=z2[:recovered_points],
                mode='lines+markers',
                line=dict(color=stage_color, width=4),
                marker=dict(size=4, color=stage_color),
                name='Recovered Data'
            ),
            # Remaining unrecovered part of second strand
            go.Scatter3d(
                x=x2[recovered_points:], y=y2[recovered_points:], z=z2[recovered_points:],
                mode='lines+markers',
                line=dict(color='lightgray', width=2),
                marker=dict(size=3, color='lightgray'),
                name='Pending Recovery'
            ),
            # Connecting lines
            go.Scatter3d(
                x=x_connect, y=y_connect, z=z_connect,
                mode='lines',
                line=dict(color=connect_colors, width=2),
                name='Data Links'
            )
        ],
        name=f'Step {step}'
    )
    return frame

def create_progress_gauge(value, title):
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=value,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': title},
        delta={'reference': 50},
        gauge={
            'axis': {'range': [0, 100]},
            'bar': {'color': "lightgreen" if value >= 70 else "orange" if value >= 40 else "red"},
            'steps': [
                {'range': [0, 40], 'color': 'lightgray'},
                {'range': [40, 70], 'color': 'gray'},
                {'range': [70, 100], 'color': 'lightgreen'}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 90
            }
        }
    ))
    return fig

def simulate_recovery(os_type, corruption_type, file_size, experiment_number):
    """Simulate file recovery process with animated visualization"""
    progress = 0
    progress_bar = st.progress(progress)
    status_text = st.empty()
    details_text = st.empty()
    animation_placeholder = st.empty()

    recovery_info = RecoveryInfo.get_os_info(os_type)
    first_method = list(recovery_info["recovery_methods"].keys())[0]
    base_success_rate = recovery_info["recovery_methods"][first_method]["success_rate"] * 100

    # Adjust success rate based on file size
    size_factor = 1 - (file_size / 100) * 0.3  # Larger files have lower success rates

    # Calculate total points for visualization
    total_points = max(50, int(file_size * 1.5))  # Minimum 50 points for visualization

    steps = {
        "Windows": {
            "Accidental Delete": [
                ("Checking Recycle Bin...", "Scanning for file signatures"),
                ("Scanning NTFS Journal...", "Analyzing file system changes"),
                ("Analyzing Master File Table...", "Reconstructing file records"),
                ("Recovering File Data...", "Reassembling data fragments")
            ],
            "Corruption": [
                ("Analyzing File Structure...", "Mapping data clusters"),
                ("Checking Shadow Copy...", "Verifying backup integrity"),
                ("Repairing File System...", "Rebuilding file structure"),
                ("Recovering Data...", "Extracting valid segments")
            ]
        },
        "MacOS": {
            "Accidental Delete": [
                ("Checking Trash...", "Validating metadata"),
                ("Scanning Time Machine...", "Reading backup states"),
                ("Analyzing File System...", "Mapping data locations"),
                ("Recovering File Data...", "Reconstructing file content")
            ],
            "Corruption": [
                ("Checking File System Journal...", "Reading journal entries"),
                ("Scanning HFS+ Catalog...", "Analyzing B-tree nodes"),
                ("Repairing File Structure...", "Rebuilding catalog"),
                ("Recovering Data...", "Extracting valid data")
            ]
        }
    }

    # Initialize animation figure
    fig = go.Figure(
        layout=go.Layout(
            title=dict(
                text="File Recovery Analysis Visualization",
                x=0.5,
                y=0.95,
                xanchor='center',
                yanchor='top'
            ),
            scene=dict(
                camera=dict(
                    eye=dict(x=1.5, y=1.5, z=0.5),
                    up=dict(x=0, y=0, z=1)
                ),
                aspectmode='manual',
                aspectratio=dict(x=1, y=1, z=2)
            ),
            showlegend=True,
            legend=dict(
                yanchor="top",
                y=0.99,
                xanchor="left",
                x=0.01
            ),
            updatemenus=[dict(
                type="buttons",
                showactive=False,
                x=0.1,
                y=1.1,
                buttons=[dict(
                    label="▶️ Analyze Recovery",
                    method="animate",
                    args=[None, dict(
                        frame=dict(duration=800, redraw=True),
                        fromcurrent=True,
                        transition=dict(duration=300, easing="quadratic-in-out")
                    )]
                )]
            )],
            annotations=[
                dict(
                    text=f"{os_type} Recovery Analysis",
                    xref="paper",
                    yref="paper",
                    x=0,
                    y=1.15,
                    showarrow=False,
                    font=dict(size=14)
                )
            ]
        )
    )

    # Initialize session state for experiment data if not exists
    if 'experiment_data' not in st.session_state:
        st.session_state.experiment_data = []

    frames = []
    final_success_rate = 0

    for step_num, (step, description) in enumerate(steps[os_type][corruption_type]):
        status_text.text(step)
        details_text.markdown(f"*{description}*")

        # Simulate step-specific success rate
        step_success = random.uniform(
            base_success_rate * size_factor * 0.8,
            base_success_rate * size_factor * 1.2
        )

        # Calculate recovered points for this step
        recovered_points = int((step_num + 1) * total_points / len(steps[os_type][corruption_type]))

        # Create and add animation frame
        frame = create_helix_frame(step_num + 1, total_points, recovered_points, os_type, step)
        frames.append(frame)

        # Update progress
        progress += 0.25
        progress_bar.progress(progress)

        # Show technical details in expandable section
        with st.expander(f"🔬 Technical Analysis - {step}"):
            if os_type == "Windows":
                st.code("""
                # Recovery Analysis Log
                > Scanning memory clusters
                > Analyzing file signatures
                > Mapping data fragments
                > Validating checksums
                > Rebuilding file structure
                """)
            else:
                st.code("""
                # Recovery Analysis Log
                > Reading volume headers
                > Checking B-tree integrity
                > Analyzing extended attributes
                > Validating data blocks
                > Rebuilding metadata
                """)

        final_success_rate = step_success

        # Update animation
        fig.frames = frames
        fig.add_trace(frames[-1].data[0])
        animation_placeholder.plotly_chart(fig, use_container_width=True)

        time.sleep(0.8)  # Animation timing

    # Store experiment data
    experiment_data = {
        'experiment_number': experiment_number,
        'os_type': os_type,
        'corruption_type': corruption_type,
        'file_size': file_size,
        'success_rate': final_success_rate
    }
    st.session_state.experiment_data.append(experiment_data)

    return min(final_success_rate, 100)

def show_experiment_results():
    if 'experiment_data' in st.session_state and st.session_state.experiment_data:
        data = st.session_state.experiment_data

        # Create comparison chart
        windows_data = [d['success_rate'] for d in data if d['os_type'] == 'Windows']
        macos_data = [d['success_rate'] for d in data if d['os_type'] == 'MacOS']

        fig = go.Figure()
        fig.add_trace(go.Box(y=windows_data, name='Windows', marker_color='lightblue'))
        fig.add_trace(go.Box(y=macos_data, name='MacOS', marker_color='lightgreen'))

        fig.update_layout(
            title="Recovery Success Rates Comparison",
            yaxis_title="Success Rate (%)",
            boxmode='group'
        )

        st.plotly_chart(fig)

        # Show data table
        st.markdown("### 📊 Experiment Data Table")
        st.dataframe(data)

def show_recovery_simulation():
    st.header("🧪 File Recovery Scientific Investigation")

    # Scientific Method Section
    with st.expander("📓 Scientific Method Guide", expanded=True):
        st.markdown("""
        ### Scientific Method Steps:
        1. **Question**: What is the relationship between file size and recovery success rate across different operating systems?
        2. **Variables**:
           * Independent Variable: Operating system type and file size
           * Dependent Variable: Recovery success rate
           * Control Variables: Corruption type, recovery method
        3. **Hypothesis**: Form a hypothesis using "If... then... because..."
        4. **Experiment**:
           * Multiple trials (at least 3 per condition)
           * Control variables
           * Record all observations
        5. **Data Collection**: Record success rates and observations
        6. **Analysis**: Calculate averages, identify patterns, create graphs
        7. **Conclusion**: Support or reject hypothesis with evidence
        """)

    # Hypothesis Section
    st.subheader("🤔 Form Your Hypothesis")
    st.markdown("*Use the format: If (change in independent variable) then (predicted change in dependent variable) because (scientific reasoning)*")
    hypothesis = st.text_area(
        "Enter your hypothesis",
        placeholder="If I increase the file size, then the recovery success rate will decrease because larger files are more complex to recover and have more data that could be corrupted."
    )
    
    # Experiment Design
    st.subheader("📋 Experiment Design")
    num_trials = st.number_input("Number of trials per condition", min_value=3, max_value=10, value=3)
    st.markdown("*Remember: More trials = more reliable results!*")

    st.markdown("---")
    st.subheader("🔬 Run Experiments")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("### Test Parameters")
        os_type = st.selectbox(
            "Select Operating System",
            ["Windows", "MacOS"],
            help="Choose the operating system you want to test"
        )

        corruption_type = st.selectbox(
            "Select Issue Type",
            ["Accidental Delete", "Corruption"],
            help="Choose what happened to your file"
        )

        file_size = st.slider(
            "File Size (MB)",
            min_value=1,
            max_value=100,
            value=10,
            help="Larger files are generally harder to recover"
        )

    with col2:
        st.markdown("### 📝 Experiment Notes")
        notes = st.text_area(
            "Record your observations",
            placeholder="Write down what you notice during the experiment..."
        )

        # Add statistical analysis
        if 'experiment_data' in st.session_state and len(st.session_state.experiment_data) > 0:
            st.markdown("### 📊 Statistical Analysis")
            
            # Calculate basic statistics
            windows_data = [d['success_rate'] for d in st.session_state.experiment_data if d['os_type'] == 'Windows']
            macos_data = [d['success_rate'] for d in st.session_state.experiment_data if d['os_type'] == 'MacOS']
            
            if windows_data and macos_data:
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Windows Average", f"{sum(windows_data)/len(windows_data):.1f}%")
                    st.metric("Windows Range", f"{max(windows_data) - min(windows_data):.1f}%")
                
                with col2:
                    st.metric("MacOS Average", f"{sum(macos_data)/len(macos_data):.1f}%")
                    st.metric("MacOS Range", f"{max(macos_data) - min(macos_data):.1f}%")

            placeholder = st.text_area(
                "Notes",
                placeholder="Write down what you notice during the experiment..."
            )

        # Get experiment number
        if 'experiment_count' not in st.session_state:
            st.session_state.experiment_count = 0

        if st.button("🚀 Run Recovery Test", help="Begin the recovery process"):
            st.session_state.experiment_count += 1
            success_rate = simulate_recovery(os_type, corruption_type, file_size, st.session_state.experiment_count)

            st.markdown("### 📊 Test Results")
            fig = create_progress_gauge(success_rate, "Recovery Success Probability")
            st.plotly_chart(fig)

            # Show recovery tips
            st.markdown("### 💡 Recovery Analysis")
            if success_rate >= 70:
                st.success(f"High recovery chance ({success_rate:.1f}%)! The {os_type} recovery system performed excellently! 🎉")
            elif success_rate >= 40:
                st.warning(f"Moderate recovery chance ({success_rate:.1f}%). The {os_type} system might need professional tools. ⚠️")
            else:
                st.error(f"Low recovery chance ({success_rate:.1f}%). The {os_type} system struggled with this scenario. ❌")

    # Show experiment results after collecting data
    if 'experiment_data' in st.session_state and len(st.session_state.experiment_data) > 0:
        st.markdown("---")
        st.subheader("📈 Experiment Results")
        show_experiment_results()

        # Add conclusion section
        st.markdown("### 🎯 Draw Your Conclusions")
        st.markdown("""
        Based on your experiment results, consider:
        1. Which system had higher average recovery rates?
        2. Was your hypothesis correct?
        3. What factors affected recovery success the most?
        4. What could you try in future experiments?
        """)

        conclusion = st.text_area(
            "Write your conclusions",
            placeholder="Based on the experimental data, I conclude that..."
        )