class RecoveryInfo:
    WINDOWS_INFO = {
        "deletion_process": [
            "File entry marked as deleted in MFT",
            "Space marked as available",
            "Data remains until overwritten",
            "File moved to Recycle Bin (if enabled)"
        ],
        "recovery_methods": {
            "Recycle Bin": {
                "success_rate": 0.99,  # Only for files in Recycle Bin
                "time_limit": "30 days default",
                "limitations": "Only if not permanently deleted"
            },
            "File Recovery Software": {
                "success_rate": 0.60,  # More realistic for deleted files
                "time_limit": "Until overwritten",
                "limitations": "Highly dependent on disk activity and time"
            },
            "Shadow Copies": {
                "success_rate": 0.85,
                "time_limit": "System restore points",
                "limitations": "System files only"
            }
        }
    }

    MACOS_INFO = {
        "deletion_process": [
            "File moved to Trash",
            "Metadata preserved",
            "Space marked as available",
            "Time Machine backup retained"
        ],
        "recovery_methods": {
            "Trash": {
                "success_rate": 0.95,
                "time_limit": "30 days default",
                "limitations": "Disk space dependent"
            },
            "Time Machine": {
                "success_rate": 0.90,
                "time_limit": "Backup schedule based",
                "limitations": "Backup drive needed"
            },
            "File System": {
                "success_rate": 0.80,
                "time_limit": "Until overwritten",
                "limitations": "Requires immediate action"
            }
        }
    }

    @staticmethod
    def get_os_info(os_type):
        return RecoveryInfo.WINDOWS_INFO if os_type == "Windows" else RecoveryInfo.MACOS_INFO

    @staticmethod
    def get_recovery_success_rate(os_type, method):
        info = RecoveryInfo.get_os_info(os_type)
        return info["recovery_methods"].get(method, {}).get("success_rate", 0.0)
