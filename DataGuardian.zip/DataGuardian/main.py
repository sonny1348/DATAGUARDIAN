import streamlit as st
from components import visualization, recovery_simulation, education
from utils import file_system
import plotly.graph_objects as go

st.set_page_config(
    page_title="File Recovery Systems Explorer",
    page_icon="🔄",
    layout="wide"
)

def main():
    st.title("📂 File Recovery Systems Explorer")
    st.subheader("Learn about Windows and MacOS File Recovery")

    # Sidebar for navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio(
        "Choose a section:",
        ["Home", "File Systems", "Recovery Simulation", "Educational Guide"]
    )

    if page == "Home":
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### Windows Recovery")
            st.write("""
            Windows uses the Recycle Bin and various file recovery tools:
            - File Record Numbers (FRN)
            - NTFS journal
            - Shadow copies
            """)

        with col2:
            st.markdown("### MacOS Recovery")
            st.write("""
            MacOS uses the Trash and Time Machine:
            - Extended attributes
            - File system snapshots
            - Versioning system
            """)

    elif page == "File Systems":
        visualization.show_file_system_comparison()

    elif page == "Recovery Simulation":
        recovery_simulation.show_recovery_simulation()

    elif page == "Educational Guide":
        education.show_educational_content()

if __name__ == "__main__":
    main()
